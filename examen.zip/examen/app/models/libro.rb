class Libro < ApplicationRecord

  belongs_to :user
end
