Rails.application.routes.draw do
  devise_for :users
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  resources :libros

=begin
  get "/articles" index
  post "/articles" create
  delete "/articles" delete
  get "/articles/:id" show
  get "/articles/new" new
  get "/articles/:id/edit" edit
  patch "/articles/:id/edit" update
  put "/articles/:id" update

=end

  root 'welcome#index'

end
